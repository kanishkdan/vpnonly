#!/bin/bash
# usage: up.sh <user> nord <country>
#        up.sh <user> profile <id>
#
# Brings up the WireGuard tunnel. Never touches the default route, and never
# routes anything by itself — route.sh decides which app groups go through it.
#
# Key material is always read from files owned by the user (mode 600), never
# passed on the command line where `ps` could see it.
set -euo pipefail

DIR0="$(cd "$(dirname "$0")" && pwd)"
IF="${IF:-utun9}"
RUSER="${1:?usage: up.sh <user> nord|profile <arg>}"
MODE="${2:-nord}"
ARG="${3:-}"

[ "$(id -u)" = 0 ] || { echo "must run as root"; exit 1; }
[ "$RUSER" != "root" ] || { echo "refusing to operate for root"; exit 1; }

# Refuse to act on behalf of a different account than the one that invoked us:
# without this, the passwordless rule would let a user run programs as someone
# else, or point the tunnel at another account's key material.
if [ -n "${SUDO_USER:-}" ] && [ "$SUDO_USER" != "root" ] && [ "$RUSER" != "$SUDO_USER" ]; then
    echo "refusing: asked to act for '$RUSER' but invoked by '$SUDO_USER'"; exit 1
fi


WG="$DIR0/bin/wg";              [ -x "$WG" ]    || WG=/opt/homebrew/bin/wg
WG_GO="$DIR0/bin/wireguard-go"; [ -x "$WG_GO" ] || WG_GO=/opt/homebrew/bin/wireguard-go

RHOME=$(dscl . -read "/Users/$RUSER" NFSHomeDirectory | awk '{print $2}')
CONF="$RHOME/.config/vpnonly"

if ifconfig "$IF" >/dev/null 2>&1; then
    echo "ALREADY_UP"; exit 0
fi

WGSET=$(mktemp); chmod 600 "$WGSET"
cleanup() { rm -f "$WGSET"; }
trap cleanup EXIT

case "$MODE" in
# ── NordVPN: their API hands us a server for the country you picked ─────────
nord)
    COUNTRY="${ARG:-sg}"
    KEYFILE="$CONF/wg.key"
    [ -f "$KEYFILE" ] || { echo "NOKEY: no WireGuard key at $KEYFILE"; exit 2; }
    CLIENT_IP=10.5.0.2          # NordLynx always assigns this

    COUNTRIES_JSON=$(curl -sf --max-time 15 https://api.nordvpn.com/v1/servers/countries || true)
    [ -n "$COUNTRIES_JSON" ] || { echo "NONET: can't reach NordVPN (no internet, or their API is down)"; exit 3; }

    CID=$(printf '%s' "$COUNTRIES_JSON" | python3 -c "
import json,sys
try:
    cs=json.load(sys.stdin)
    print(next(c['id'] for c in cs if c['code'].lower()=='$COUNTRY'.lower()))
except Exception:
    sys.exit(1)
" 2>/dev/null || true)
    [ -n "$CID" ] || { echo "BADCOUNTRY: no NordVPN servers found for '$COUNTRY'"; exit 4; }

    REC_JSON=$(curl -sf --max-time 15 "https://api.nordvpn.com/v1/servers/recommendations?filters\[country_id\]=$CID&filters\[servers_technologies\]\[identifier\]=wireguard_udp&limit=1" || true)
    [ -n "$REC_JSON" ] || { echo "NONET: can't reach NordVPN server list"; exit 3; }

    read -r HOST STATION PUBKEY <<< "$(printf '%s' "$REC_JSON" | python3 -c "
import json,sys
try:
    s=json.load(sys.stdin)[0]
    pk=next(m['value'] for t in s['technologies'] if t['identifier']=='wireguard_udp' for m in t.get('metadata',[]))
    print(s['hostname'], s['station'], pk)
except Exception:
    sys.exit(1)
" 2>/dev/null || true)"
    [ -n "${PUBKEY:-}" ] || { echo "NOSERVER: NordVPN returned no usable server for '$COUNTRY'"; exit 5; }

    {
        echo "[Interface]"
        echo "PrivateKey = $(cat "$KEYFILE")"
        echo "[Peer]"
        echo "PublicKey = $PUBKEY"
        echo "Endpoint = $STATION:51820"
        echo "AllowedIPs = 0.0.0.0/0"
        echo "PersistentKeepalive = 25"
    } > "$WGSET"
    LABEL="$HOST"
    ;;

# ── Any other provider: a WireGuard config the user imported ───────────────
profile)
    [ -n "$ARG" ] || { echo "BADPROFILE: no profile given"; exit 7; }
    case "$ARG" in *[!A-Za-z0-9._-]*) echo "BADPROFILE: bad id"; exit 7 ;; esac
    PCONF="$CONF/profiles/$ARG.conf"
    [ -f "$PCONF" ] || { echo "NOPROFILE: $ARG not found"; exit 7; }

    # Reduce the provider's config to what `wg setconf` accepts, and pull out
    # the interface address (Mullvad hands out 10.64.x.x, others differ).
    PARSED=$("$DIR0/parse-wg.py" "$PCONF" "$WGSET" 2>&1) || { echo "BADCONFIG: $PARSED"; exit 8; }
    CLIENT_IP=$(echo "$PARSED" | awk '{print $1}')
    LABEL=$(echo "$PARSED" | awk '{print $2}')
    ;;
*)
    echo "usage: up.sh <user> nord|profile <arg>"; exit 1 ;;
esac

[ -x "$DIR0/vpnrun" ] || { echo "vpnrun missing from engine"; exit 1; }

cleanup_on_fail() { pkill -f "wireguard-go $IF" 2>/dev/null; rm -f "$WGSET"; }
trap cleanup_on_fail ERR

"$WG_GO" "$IF"
"$WG" setconf "$IF" "$WGSET"

# Providers' configs often omit PersistentKeepalive. Without it an idle tunnel
# sends nothing, so NAT on the way out forgets the mapping and the tunnel goes
# quietly deaf. 25s is what wg-quick and the commercial clients use.
for pk in $("$WG" show "$IF" peers 2>/dev/null); do
    "$WG" set "$IF" peer "$pk" persistent-keepalive 25 2>/dev/null || true
done
ifconfig "$IF" inet "$CLIENT_IP" "$CLIENT_IP" netmask 255.255.255.255 mtu 1420 up

# route.sh needs the tunnel address for its NAT rule
printf '%s\n' "$CLIENT_IP" > "$CONF/tunnel-ip"
chown "$RUSER" "$CONF/tunnel-ip" 2>/dev/null || true

trap cleanup EXIT
echo "CONNECTED host=$LABEL"
