#!/bin/bash
# One-time privileged install: copies the engine to a root-owned location and
# adds a narrowly-scoped sudoers rule so the menu bar app can operate the
# tunnel without prompting for a password on every click.
#
# Security model: the engine directory is owned by root and not writable by
# any user, and the sudoers rule allows ONLY these exact scripts. The scripts
# refuse to operate for root, vpnrun refuses to launch anything as uid 0, and
# only groups named vpn_* can ever be created or routed.
set -euo pipefail

SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="/Library/Application Support/VPNonly/engine"

# The passwordless rule is granted to one named user, not to %admin: on a Mac
# with several admin accounts, a blanket rule would let any of them run these
# as root without a password.
INSTALL_USER="${1:-${SUDO_USER:-}}"
[ -n "$INSTALL_USER" ] || { echo "usage: install.sh <username>"; exit 1; }
case "$INSTALL_USER" in
    *[!A-Za-z0-9._-]*) echo "refusing odd username: $INSTALL_USER"; exit 1 ;;
esac
[ "$INSTALL_USER" != "root" ] || { echo "refusing to install for root"; exit 1; }
id "$INSTALL_USER" >/dev/null 2>&1 || { echo "no such user: $INSTALL_USER"; exit 1; }

mkdir -p "$DEST/bin"
cp "$SRC/up.sh" "$SRC/down.sh" "$SRC/run.sh" "$SRC/route.sh" "$SRC/group.sh" "$SRC/parse-wg.py" "$SRC/uninstall.sh" "$SRC/VERSION" "$DEST/"
cp "$SRC/THIRD-PARTY-NOTICES.txt" "$SRC/wireguard-tools-GPLv2.txt" "$SRC/wireguard-go-MIT.txt" "$DEST/" 2>/dev/null || true
cp "$SRC/vpnrun" "$DEST/vpnrun"
cp "$SRC/bin/wg" "$SRC/bin/wireguard-go" "$DEST/bin/"
chown -R root:wheel "/Library/Application Support/VPNonly"
chmod 755 "$DEST" "$DEST/bin" "$DEST"/*.sh "$DEST/parse-wg.py" "$DEST/vpnrun" "$DEST/bin/"*
chmod 644 "$DEST/VERSION"

TMP=$(mktemp)
cat > "$TMP" <<EOF
Cmnd_Alias VPNONLY = /Library/Application\\ Support/VPNonly/engine/up.sh *, /Library/Application\\ Support/VPNonly/engine/down.sh, /Library/Application\\ Support/VPNonly/engine/down.sh *, /Library/Application\\ Support/VPNonly/engine/run.sh *, /Library/Application\\ Support/VPNonly/engine/route.sh *, /Library/Application\\ Support/VPNonly/engine/group.sh *
$INSTALL_USER ALL=(root) NOPASSWD: VPNONLY
EOF
visudo -cf "$TMP"
install -m 0440 -o root -g wheel "$TMP" /etc/sudoers.d/vpnonly
rm -f "$TMP"
echo "INSTALLED"
