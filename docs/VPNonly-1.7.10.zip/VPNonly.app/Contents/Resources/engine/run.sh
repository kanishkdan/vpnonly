#!/bin/bash
# usage: run.sh <user> <vpn_group> </Applications/App.app or /path/to/binary> [args...]
# Launches a program tagged with its VPN group. Whether that group's traffic
# actually goes through the tunnel is decided separately by route.sh.
set -euo pipefail

DIR="$(cd "$(dirname "$0")" && pwd)"
RUSER="${1:?usage: run.sh <user> <group> <app> [args...]}"; shift
GROUP="${1:?usage: run.sh <user> <group> <app> [args...]}"; shift
[ "$RUSER" != "root" ] || { echo "refusing to launch as root"; exit 1; }

# Refuse to act on behalf of a different account than the one that invoked us:
# without this, the passwordless rule would let a user run programs as someone
# else, or point the tunnel at another account's key material.
if [ -n "${SUDO_USER:-}" ] && [ "$SUDO_USER" != "root" ] && [ "$RUSER" != "$SUDO_USER" ]; then
    echo "refusing: asked to act for '$RUSER' but invoked by '$SUDO_USER'"; exit 1
fi

[ "$(id -u)" = 0 ] || { echo "must run as root"; exit 1; }
TARGET="${1:?usage: run.sh <user> <group> <app> [args...]}"; shift || true

if [ -d "$TARGET" ] && [[ "$TARGET" == *.app ]]; then
    EXE=$(defaults read "$TARGET/Contents/Info" CFBundleExecutable)
    BIN="$TARGET/Contents/MacOS/$EXE"
    GUI=1
else
    BIN="$TARGET"
    GUI=0
fi
[ -x "$BIN" ] || { echo "not executable: $BIN"; exit 1; }
[ -x "$DIR/vpnrun" ] || { echo "vpnrun missing from engine"; exit 1; }

if [ "$GUI" = 1 ]; then
    "$DIR/vpnrun" "$RUSER" "$GROUP" "$BIN" "$@" >/dev/null 2>&1 &
    echo "LAUNCHED pid=$! bin=$BIN"
else
    exec "$DIR/vpnrun" "$RUSER" "$GROUP" "$BIN" "$@"
fi
