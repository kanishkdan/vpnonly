#!/bin/bash
# usage: route.sh <user> [group ...]
#
# Applies the complete desired routing state in one shot: every group listed
# is steered into the tunnel; every group not listed is left alone. Idempotent,
# so the app can just declare what it wants and never track deltas.
#
# Because group membership is fixed at process start but PF rules are not,
# this is what makes toggling an app in/out of the VPN instant — no restart.
#
# NOTE: macOS ships bash 3.2, where GROUPS is a reserved array — never use
# that name here.
set -euo pipefail

IF="${IF:-utun9}"
[ "$(id -u)" = 0 ] || { echo "must run as root"; exit 1; }
RUSER="${1:?usage: route.sh <user> [group ...]}"; shift || true
[ "$RUSER" != "root" ] || { echo "refusing to operate for root"; exit 1; }

# Refuse to act on behalf of a different account than the one that invoked us:
# without this, the passwordless rule would let a user run programs as someone
# else, or point the tunnel at another account's key material.
if [ -n "${SUDO_USER:-}" ] && [ "$SUDO_USER" != "root" ] && [ "$RUSER" != "$SUDO_USER" ]; then
    echo "refusing: asked to act for '$RUSER' but invoked by '$SUDO_USER'"; exit 1
fi


RHOME=$(dscl . -read "/Users/$RUSER" NFSHomeDirectory | awk '{print $2}')
CONF="$RHOME/.config/vpnonly"
mkdir -p "$CONF"

# whatever address the active tunnel actually got (Nord uses 10.5.0.2,
# Mullvad hands out 10.64.x.x, self-hosted is anything)
CLIENT_IP=$(cat "$CONF/tunnel-ip" 2>/dev/null || echo 10.5.0.2)
case "$CLIENT_IP" in
    [0-9]*.[0-9]*.[0-9]*.[0-9]*) ;;
    *) CLIENT_IP=10.5.0.2 ;;
esac

# Only ever touch groups we created, in our private gid range. A firewall
# rule aimed at a system or login group could take the whole machine off the
# network, so this refuses rather than risks it.
VPNG=""
NVPNG=0
for g in "$@"; do
    case "$g" in
        vpn_*) ;;
        *) echo "REFUSED non-vpn group: $g" >&2; continue ;;
    esac
    gid=$(dscl . -read "/Groups/$g" PrimaryGroupID 2>/dev/null | awk '{print $2}')
    if [ -z "${gid:-}" ]; then
        echo "REFUSED unknown group: $g" >&2; continue
    fi
    if [ "$gid" -lt 7100 ] || [ "$gid" -ge 7900 ]; then
        echo "REFUSED group $g: gid $gid outside VPNonly range" >&2; continue
    fi
    VPNG="$VPNG $g"
    NVPNG=$((NVPNG + 1))
done

TUNNEL_UP=0
ifconfig "$IF" >/dev/null 2>&1 && TUNNEL_UP=1

# Nothing routed and no tunnel -> hand the machine back to the stock ruleset.
if [ "$NVPNG" -eq 0 ] && [ "$TUNNEL_UP" -eq 0 ]; then
    pfctl -q -f /etc/pf.conf 2>/dev/null || true
    if [ -s "$CONF/pf-token" ]; then
        pfctl -X "$(cat "$CONF/pf-token")" 2>/dev/null || true
        rm -f "$CONF/pf-token"
    fi
    echo "ROUTES none tunnel=0"
    exit 0
fi

PFMERGED="$CONF/pf-merged.conf"
{
    echo 'set skip on lo0'
    if [ "$TUNNEL_UP" -eq 1 ]; then
        awk -v nat="nat on $IF inet from any to any -> $CLIENT_IP" \
            '{print} /^rdr-anchor/{print nat}' /etc/pf.conf
    else
        cat /etc/pf.conf
    fi
    for g in $VPNG; do
        # kill switch first: applies whenever the pass rule below is absent,
        # i.e. any time the tunnel is not up. Traffic is refused, never leaked.
        echo "block return out proto { tcp udp } from any to any group $g"
        if [ "$TUNNEL_UP" -eq 1 ]; then
            echo "pass out quick route-to ($IF $CLIENT_IP) inet proto { tcp udp } from any to any group $g keep state"
        fi
    done
} > "$PFMERGED"

# Parse-check before loading. A malformed ruleset must never reach the kernel.
if ! pfctl -n -f "$PFMERGED" 2>/dev/null; then
    echo "BADRULES: generated ruleset failed validation, restoring stock" >&2
    pfctl -q -f /etc/pf.conf 2>/dev/null || true
    exit 6
fi

pfctl -q -f "$PFMERGED"
if [ ! -s "$CONF/pf-token" ]; then
    pfctl -E 2>&1 | awk '/Token/{print $NF}' > "$CONF/pf-token" || true
fi
echo "ROUTES${VPNG:- none} tunnel=$TUNNEL_UP"
