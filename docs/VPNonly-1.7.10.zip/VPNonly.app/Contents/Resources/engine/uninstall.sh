#!/bin/bash
# Removes everything VPNonly ever put on this machine, root-owned bits included.
# Run with administrator privileges. Safe to run twice.
#
#   sudo "/Library/Application Support/VPNonly/engine/uninstall.sh" [username]
#
# Deleting the app alone would leave a root-owned engine and a sudoers entry
# behind, so this exists and is documented. Nothing here touches your VPN
# provider account or your own config files in ~/.config/vpnonly.
set -uo pipefail

IF="${IF:-utun9}"
[ "$(id -u)" = 0 ] || { echo "must run as root (use sudo)"; exit 1; }
RUSER="${1:-${SUDO_USER:-}}"

echo "Restoring macOS's own firewall rules…"
pfctl -q -f /etc/pf.conf 2>/dev/null

if [ -n "$RUSER" ] && [ "$RUSER" != "root" ]; then
    RHOME=$(dscl . -read "/Users/$RUSER" NFSHomeDirectory 2>/dev/null | awk '{print $2}')
    if [ -n "${RHOME:-}" ] && [ -s "$RHOME/.config/vpnonly/pf-token" ]; then
        pfctl -X "$(cat "$RHOME/.config/vpnonly/pf-token")" 2>/dev/null
        rm -f "$RHOME/.config/vpnonly/pf-token" "$RHOME/.config/vpnonly/tunnel-ip" \
              "$RHOME/.config/vpnonly/pf-merged.conf"
    fi
fi

echo "Closing the tunnel…"
pkill -f "wireguard-go $IF" 2>/dev/null
rm -f "/var/run/wireguard/$IF.sock" 2>/dev/null

echo "Removing the per-app groups…"
for g in $(dscl . -list /Groups 2>/dev/null | grep '^vpn_' || true); do
    dseditgroup -o delete "$g" 2>/dev/null && echo "  removed $g"
done

echo "Removing the passwordless rule…"
rm -f /etc/sudoers.d/vpnonly

echo "Removing the engine…"
rm -rf "/Library/Application Support/VPNonly"

echo
echo "Done. VPNonly is off this machine."
echo "Your own files (WireGuard keys, imported configs, licence) are still in"
echo "~/.config/vpnonly and ~/Library/Application Support/VPNonly — delete those"
echo "yourself if you want them gone. Drag VPNonly.app to the Trash to finish."
