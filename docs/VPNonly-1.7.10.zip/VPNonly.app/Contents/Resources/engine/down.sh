#!/bin/bash
# usage: down.sh [user]
# Tears down the split tunnel and restores stock PF rules.
set -uo pipefail

IF="${IF:-utun9}"
[ "$(id -u)" = 0 ] || { echo "must run as root"; exit 1; }
RUSER="${1:-${SUDO_USER:-$USER}}"
RHOME=$(dscl . -read "/Users/$RUSER" NFSHomeDirectory 2>/dev/null | awk '{print $2}')
CONF="${RHOME:-/tmp}/.config/vpnonly"

pfctl -q -f /etc/pf.conf 2>/dev/null
if [ -s "$CONF/pf-token" ]; then
    pfctl -X "$(cat "$CONF/pf-token")" 2>/dev/null
    rm -f "$CONF/pf-token"
fi
pkill -f "wireguard-go $IF" 2>/dev/null
rm -f "/var/run/wireguard/$IF.sock" "$CONF/tunnel-ip" 2>/dev/null
echo "DISCONNECTED"
