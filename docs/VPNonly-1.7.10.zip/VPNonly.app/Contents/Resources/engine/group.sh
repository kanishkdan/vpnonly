#!/bin/bash
# usage: group.sh <user> <vpn_xxxx>
# Ensures a dedicated group exists for one app. Prints its gid.
set -euo pipefail

[ "$(id -u)" = 0 ] || { echo "must run as root"; exit 1; }
RUSER="${1:?usage: group.sh <user> <group>}"
GROUP="${2:?usage: group.sh <user> <group>}"
[ "$RUSER" != "root" ] || { echo "refusing to operate for root"; exit 1; }

# Refuse to act on behalf of a different account than the one that invoked us:
# without this, the passwordless rule would let a user run programs as someone
# else, or point the tunnel at another account's key material.
if [ -n "${SUDO_USER:-}" ] && [ "$SUDO_USER" != "root" ] && [ "$RUSER" != "$SUDO_USER" ]; then
    echo "refusing: asked to act for '$RUSER' but invoked by '$SUDO_USER'"; exit 1
fi

case "$GROUP" in vpn_*) ;; *) echo "group must start with vpn_"; exit 1 ;; esac

if GID=$(dscl . -read "/Groups/$GROUP" PrimaryGroupID 2>/dev/null | awk '{print $2}') && [ -n "${GID:-}" ]; then
    echo "GID $GID"
    exit 0
fi

# allocate from a private range so we never collide with system or user ids
USED=$(dscl . -list /Groups PrimaryGroupID | awk '$2>=7100 && $2<7900 {print $2}' | sort -n | tail -1)
GID=$(( ${USED:-7099} + 1 ))
dseditgroup -o create -i "$GID" -r "VPNonly app group" "$GROUP" >/dev/null
echo "GID $GID"
