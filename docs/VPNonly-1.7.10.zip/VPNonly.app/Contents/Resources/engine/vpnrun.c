/*
 * vpnrun — launch a program under a given VPN group so PF can steer its
 * traffic. Must be started as root; drops to the target user before exec.
 *
 * usage: vpnrun <user> <group> <absolute-path-to-binary> [args...]
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <grp.h>
#include <pwd.h>

int main(int argc, char **argv) {
    if (argc < 4) {
        fprintf(stderr, "usage: %s <user> <group> <program> [args...]\n", argv[0]);
        return 1;
    }
    /* only ever operate on our own groups */
    if (strncmp(argv[2], "vpn_", 4) != 0) {
        fprintf(stderr, "refusing group '%s' (must start with vpn_)\n", argv[2]);
        return 1;
    }
    struct group *g = getgrnam(argv[2]);
    if (!g) { fprintf(stderr, "group '%s' not found\n", argv[2]); return 1; }

    struct passwd *p = getpwnam(argv[1]);
    if (!p) { fprintf(stderr, "user '%s' not found\n", argv[1]); return 1; }
    if (p->pw_uid == 0) { fprintf(stderr, "refusing to launch as root\n"); return 1; }

    gid_t only[1] = { g->gr_gid };
    if (setgroups(1, only) != 0) { perror("setgroups"); return 1; }
    if (setgid(g->gr_gid) != 0)  { perror("setgid");    return 1; }
    if (setuid(p->pw_uid) != 0)  { perror("setuid");    return 1; }

    execv(argv[3], &argv[3]);
    perror("execv");
    return 1;
}
